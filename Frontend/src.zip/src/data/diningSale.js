<Box>
              <Image src="https://assets.wfcdn.com/im/48655380/resize-h400-w400%5Ecompr-r85/1222/122209959/Cache+2-Door+Accent+Cabinet.jpg" />
              <Link href="wayfairRewards">Cache 2-Door Accent Cabinet</Link>
              <Heading>$139.83</Heading>
              <Text>$425.00</Text>
            </Box>
const diningSale = [
    {
    image:"https://assets.wfcdn.com/im/48655380/resize-h400-w400%5Ecompr-r85/1222/122209959/Cache+2-Door+Accent+Cabinet.jpg",
    link: "wayfairRewards",
    linkText: "Cache 2-Door Accent Cabinet",
    price: "$139.83",
    mrp: "$425.00"
    },

]