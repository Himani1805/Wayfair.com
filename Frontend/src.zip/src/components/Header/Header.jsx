import { Flex, VStack, Link, Text } from "@chakra-ui/react";
import React from "react";
// import { Link } from "react-router-dom";
import { MdOutlineAccountCircle } from "react-icons/md";
import { AiOutlineShoppingCart } from "react-icons/ai";
import SearchBar from "./SearchBar";
import { FaArrowRight } from "react-icons/fa";

export default function Header() {
  return (
    <VStack border={"2px solid red"} width={"100%"}>
      <Flex border={"2px solid green"} width={"100%"} justifyContent={"space-between"} px={" 60px"} py={"4px"} background={"#7c189f"} >
        <Link color="white" _hover={{textDecoration:"underline"}}>SPRING CYBER WEEK | UP TO 80% OFF ENDS TOMORROW <FaArrowRight color="white" /></Link>
        <Link color="white" _hover={{textDecoration:"underline"}}>Rewards | Financing | Professional | Everything Ships FREE*</Link>
      </Flex>
      <Flex border={"2px solid red"} width={"100%"}>
        <Flex width={"15%"}>
        <Text fontWeight="bold" fontSize="xl" color="purple.500">Wayfair</Text>

        </Flex>
        <Flex width={"70%"}>
          <SearchBar />
        </Flex>
        <Flex width={"30%"}>
            <Link href=""><MdOutlineAccountCircle  _hover={{color:"#7c189f"}}/>  Account</Link>
            <Link><AiOutlineShoppingCart _hover={{color:"#7c189f"}}/>Cart</Link>
        </Flex>

      </Flex>
    </VStack>
  );
}
